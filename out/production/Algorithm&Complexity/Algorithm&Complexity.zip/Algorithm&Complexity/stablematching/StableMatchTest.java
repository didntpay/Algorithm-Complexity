package stablematching;
import org.junit.Test;

public class StableMatchTest {
    @Test
    public void givenTestCases(){

        /*int[][] m = {{1, 2, 0},
                    {0, 1, 2},
                    {2, 1, 0}};
        int[][] w = {{0, 1, 2},
                    {1, 0, 2},
                    {2, 1, 0}};*/
        /*int[][] m = {{3, 1, 0, 2},
                    {3, 0, 1, 2},
                    {3, 1, 2, 0},
                    {0, 3, 2, 1}};
        int[][] w = {{3, 0, 2, 1},
                    {3, 1, 2, 0},
                    {0, 1, 3, 2},
                    {3, 0, 2, 1}};*/
        /*int[][] m = {{4, 2, 0, 1, 3},
                {0, 1, 4, 2, 3},
                {4, 0, 1, 3, 2},
                {1, 4, 3, 0, 2},
                {0, 1, 3, 4, 2}};
        int[][] w = {{2, 3, 4, 0, 1},
                {2, 4, 0, 3, 1},
                {1, 4, 2, 3, 0},
                {3, 0, 1, 4, 2},
                {0, 3, 1, 2, 4}};*/

        //StableMatch match = new StableMatch(m, w);
        //int[] result = match.findMatching();

        RandomGenerator genMatrix = new RandomGenerator();
        double[] wholder = new double[1000];
        double[] mholder = new double[1000];
        for (int j = 0; j < 5; j++){
            for (int i = 1; i < 1000; i++){
                int[][] m = genMatrix.generateRandomMatrix(i);
                int[][] w = genMatrix.generateRandomMatrix(i);
                StableMatch match = new StableMatch(m, w);
                int[] result = match.findMatching();
                wholder[i] += match.wGoodNess(result);
                mholder[i] += match.mGoodNess(result);
            }
        }

        for (int i = 0; i < 1000; i++){
            System.out.print(wholder[i] / 10 + "\t");
            System.out.println(mholder[i] / 10);
            //System.out.println("");
        }

       /*for (int i = 0; i < result.length; i++){
            System.out.println(result[i]);
        }*/
    }
}
